﻿#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

const string FILENAME = "students.csv";

// 学生信息结构体
struct Student {
    string college;
    string major;
    string className;
    string id;
    string name;
    int age;
    string gender;
    string birth;
    string address;
    string phone;
    string email;
    string dorm;
    string politics;
    Student* next;

    Student() : next(nullptr) {}
};

// 学生管理类
class StudentManager {
private:
    Student* head;

    // 释放链表内存
    void freeList() {
        Student* current = head;
        while (current != nullptr) {
            Student* temp = current;
            current = current->next;
            delete temp;
        }
        head = nullptr;
    }

    // 按学号查找学生
    Student* findById(const string& id) {
        Student* current = head;
        while (current != nullptr) {
            if (current->id == id) return current;
            current = current->next;
        }
        return nullptr;
    }

    // 按姓名查找学生
    void findByName(const string& name) {
        Student* current = head;
        bool found = false;
        while (current != nullptr) {
            if (current->name == name) {
                displayStudent(current);
                found = true;
            }
            current = current->next;
        }
        if (!found) cout << "未找到姓名: " << name << endl;
    }

    // 显示单个学生信息
    void displayStudent(Student* student) {
        cout << "学院: " << student->college << endl;
        cout << "专业: " << student->major << endl;
        cout << "班级: " << student->className << endl;
        cout << "学号: " << student->id << endl;
        cout << "姓名: " << student->name << endl;
        cout << "年龄: " << student->age << endl;
        cout << "性别: " << student->gender << endl;
        cout << "出生日期: " << student->birth << endl;
        cout << "地址: " << student->address << endl;
        cout << "电话: " << student->phone << endl;
        cout << "邮箱: " << student->email << endl;
        cout << "宿舍号: " << student->dorm << endl;
        cout << "政治面貌: " << student->politics << endl;
        cout << "------------------------" << endl;
    }

    // 处理 CSV 字段中的逗号和双引号
    string escapeCSV(const string& input) {
        string result = input;
        if (result.find(',') != string::npos || result.find('"') != string::npos) {
            string escaped;
            escaped += '"';
            for (char c : result) {
                if (c == '"') escaped += "\"\"";
                else escaped += c;
            }
            escaped += '"';
            return escaped;
        }
        return result;
    }

    // 解析 CSV 字段
    string unescapeCSV(const string& input) {
        if (input.empty() || input[0] != '"') return input;
        string result;
        bool inQuote = false;
        for (size_t i = 0; i < input.size(); ++i) {
            if (input[i] == '"' && i + 1 < input.size() && input[i + 1] == '"') {
                result += '"';
                ++i;
            }
            else if (input[i] == '"') {
                inQuote = !inQuote;
            }
            else if (!inQuote) {
                result += input[i];
            }
        }
        return result;
    }

public:
    StudentManager() : head(nullptr) {
        loadFromFile();
    }

    ~StudentManager() {
        saveToFile();
        freeList();
    }

    // 显示菜单
    void menu() {
        cout << "\n=== 学生信息管理系统 ===" << endl;
        cout << "1. 添加学生信息" << endl;
        cout << "2. 浏览学生信息" << endl;
        cout << "3. 查询学生信息" << endl;
        cout << "4. 删除学生信息" << endl;
        cout << "5. 修改学生信息" << endl;
        cout << "6. 排序学生信息" << endl;
        cout << "7. 筛选学生信息" << endl;
        cout << "0. 退出系统" << endl;
    }

    // 添加学生 (Create)
    void addStudent() {
        Student* newStudent = new Student();
        cout << "请输入学院: ";
        getline(cin, newStudent->college);
        cout << "请输入专业: ";
        getline(cin, newStudent->major);
        cout << "请输入班级: ";
        getline(cin, newStudent->className);
        cout << "请输入学号: ";
        getline(cin, newStudent->id);
        cout << "请输入姓名: ";
        getline(cin, newStudent->name);
        cout << "请输入年龄: ";
        string ageInput;
        getline(cin, ageInput);
        try {
            newStudent->age = stoi(ageInput);
        }
        catch (...) {
            cout << "年龄输入无效，设置为0" << endl;
            newStudent->age = 0;
        }
        cout << "请输入性别: ";
        getline(cin, newStudent->gender);
        cout << "请输入出生日期: ";
        getline(cin, newStudent->birth);
        cout << "请输入地址: ";
        getline(cin, newStudent->address);
        cout << "请输入电话: ";
        getline(cin, newStudent->phone);
        cout << "请输入邮箱: ";
        getline(cin, newStudent->email);
        cout << "请输入宿舍号: ";
        getline(cin, newStudent->dorm);
        cout << "请输入政治面貌: ";
        getline(cin, newStudent->politics);

        newStudent->next = head;
        head = newStudent;
        saveToFile(); // 立即保存
        cout << "学生信息添加成功！" << endl;
    }

    // 保存到 CSV 文件
    void saveToFile() {
        ofstream outFile(FILENAME);
        if (!outFile) {
            cout << "无法打开文件 " << FILENAME << " 进行写入！" << endl;
            return;
        }
        // 写入 CSV 表头
        outFile << "college,major,className,id,name,age,gender,birth,address,phone,email,dorm,politics\n";
        Student* current = head;
        while (current != nullptr) {
            outFile << escapeCSV(current->college) << ","
                << escapeCSV(current->major) << ","
                << escapeCSV(current->className) << ","
                << escapeCSV(current->id) << ","
                << escapeCSV(current->name) << ","
                << current->age << ","
                << escapeCSV(current->gender) << ","
                << escapeCSV(current->birth) << ","
                << escapeCSV(current->address) << ","
                << escapeCSV(current->phone) << ","
                << escapeCSV(current->email) << ","
                << escapeCSV(current->dorm) << ","
                << escapeCSV(current->politics) << "\n";
            current = current->next;
        }
        outFile.close();
        cout << "数据已保存到 " << FILENAME << endl;
    }

    // 从 CSV 文件加载
    void loadFromFile() {
        ifstream inFile(FILENAME);
        if (!inFile) {
            cout << "文件 " << FILENAME << " 不存在，将创建新文件。" << endl;
            return;
        }
        string line;
        // 跳过表头
        getline(inFile, line);
        while (getline(inFile, line)) {
            stringstream ss(line);
            string field;
            vector<string> fields;
            bool inQuotes = false;
            string currentField;

            // 解析 CSV 行
            while (getline(ss, field, ',')) {
                if (!inQuotes && field.front() == '"') {
                    inQuotes = true;
                    currentField = field.substr(1);
                    continue;
                }
                if (inQuotes) {
                    currentField += "," + field;
                    if (field.back() == '"') {
                        inQuotes = false;
                        currentField = currentField.substr(0, currentField.size() - 1);
                        fields.push_back(unescapeCSV(currentField));
                        currentField.clear();
                    }
                    continue;
                }
                fields.push_back(unescapeCSV(field));
            }

            if (fields.size() >= 13) {
                Student* newStudent = new Student();
                newStudent->college = fields[0];
                newStudent->major = fields[1];
                newStudent->className = fields[2];
                newStudent->id = fields[3];
                newStudent->name = fields[4];
                try {
                    newStudent->age = stoi(fields[5]);
                }
                catch (...) {
                    newStudent->age = 0;
                    cout << "警告：学号 " << newStudent->id << " 的年龄数据无效，设置为0" << endl;
                }
                newStudent->gender = fields[6];
                newStudent->birth = fields[7];
                newStudent->address = fields[8];
                newStudent->phone = fields[9];
                newStudent->email = fields[10];
                newStudent->dorm = fields[11];
                newStudent->politics = fields[12];
                newStudent->next = head;
                head = newStudent;
            }
            else {
                cout << "警告：忽略无效行，字段数：" << fields.size() << endl;
            }
        }
        inFile.close();
        cout << "已从 " << FILENAME << " 加载数据" << endl;
    }

    // 浏览学生信息 (Read)
    void displayStudents() {
        if (head == nullptr) {
            cout << "没有学生信息！" << endl;
            return;
        }
        Student* current = head;
        while (current != nullptr) {
            displayStudent(current);
            current = current->next;
        }
    }

    // 查询学生信息 (Read)
    void searchStudent() {
        int choice;
        string key;
        cout << "1. 按学号查询" << endl;
        cout << "2. 按姓名查询" << endl;
        cout << "请选择: ";
        cin >> choice;
        cin.ignore();
        if (choice == 1) {
            cout << "请输入学号: ";
            getline(cin, key);
            Student* student = findById(key);
            if (student) {
                displayStudent(student);
            }
            else {
                cout << "未找到学号: " << key << endl;
            }
        }
        else if (choice == 2) {
            cout << "请输入姓名: ";
            getline(cin, key);
            findByName(key);
        }
        else {
            cout << "无效选择！" << endl;
        }
    }

    // 删除学生信息 (Delete)
    void deleteStudent() {
        string id;
        cout << "请输入要删除学生的学号: ";
        getline(cin, id);
        Student* current = head;
        Student* prev = nullptr;
        while (current != nullptr && current->id != id) {
            prev = current;
            current = current->next;
        }
        if (current == nullptr) {
            cout << "未找到学号: " << id << endl;
            return;
        }
        if (prev == nullptr) {
            head = current->next;
        }
        else {
            prev->next = current->next;
        }
        delete current;
        saveToFile(); // 立即保存
        cout << "学生信息删除成功！" << endl;
    }

    // 修改学生信息 (Update)
    void modifyStudent() {
        string id;
        cout << "请输入要修改学生的学号: ";
        getline(cin, id);
        Student* student = findById(id);
        if (student == nullptr) {
            cout << "未找到学号: " << id << endl;
            return;
        }
        cout << "请输入新信息（直接回车保留原信息）:" << endl;
        string input;
        cout << "学院(" << student->college << "): ";
        getline(cin, input);
        if (!input.empty()) student->college = input;
        cout << "专业(" << student->major << "): ";
        getline(cin, input);
        if (!input.empty()) student->major = input;
        cout << "班级(" << student->className << "): ";
        getline(cin, input);
        if (!input.empty()) student->className = input;
        cout << "姓名(" << student->name << "): ";
        getline(cin, input);
        if (!input.empty()) student->name = input;
        cout << "年龄(" << student->age << "): ";
        getline(cin, input);
        if (!input.empty()) {
            try {
                student->age = stoi(input);
            }
            catch (...) {
                cout << "年龄输入无效，保留原值" << endl;
            }
        }
        cout << "性别(" << student->gender << "): ";
        getline(cin, input);
        if (!input.empty()) student->gender = input;
        cout << "出生日期(" << student->birth << "): ";
        getline(cin, input);
        if (!input.empty()) student->birth = input;
        cout << "地址(" << student->address << "): ";
        getline(cin, input);
        if (!input.empty()) student->address = input;
        cout << "电话(" << student->phone << "): ";
        getline(cin, input);
        if (!input.empty()) student->phone = input;
        cout << "邮箱(" << student->email << "): ";
        getline(cin, input);
        if (!input.empty()) student->email = input;
        cout << "宿舍号(" << student->dorm << "): ";
        getline(cin, input);
        if (!input.empty()) student->dorm = input;
        cout << "政治面貌(" << student->politics << "): ";
        getline(cin, input);
        if (!input.empty()) student->politics = input;
        saveToFile(); // 立即保存
        cout << "学生信息修改成功！" << endl;
    }

    // 排序学生信息
    void sortStudents() {
        int choice;
        cout << "1. 按学号排序" << endl;
        cout << "2. 按年龄排序" << endl;
        cout << "请选择: ";
        cin >> choice;
        cin.ignore();

        // 将链表转换为向量以便排序
        vector<Student*> students;
        Student* current = head;
        while (current != nullptr) {
            students.push_back(current);
            current = current->next;
        }
        if (students.empty()) {
            cout << "没有学生信息！" << endl;
            return;
        }

        // 排序
        if (choice == 1) {
            sort(students.begin(), students.end(), [](Student* a, Student* b) {
                return a->id < b->id;
                });
        }
        else if (choice == 2) {
            sort(students.begin(), students.end(), [](Student* a, Student* b) {
                return a->age < b->age;
                });
        }
        else {
            cout << "无效选择！" << endl;
            return;
        }

        // 重建链表
        head = students[0];
        current = head;
        for (size_t i = 1; i < students.size(); i++) {
            current->next = students[i];
            current = current->next;
        }
        current->next = nullptr;
        saveToFile(); // 立即保存
        cout << "排序完成！" << endl;
    }

    // 筛选学生信息
    void filterStudents() {
        int choice;
        string key;
        cout << "筛选条件:" << endl;
        cout << "1. 按学院" << endl;
        cout << "2. 按专业" << endl;
        cout << "3. 按班级" << endl;
        cout << "4. 按性别" << endl;
        cout << "5. 按政治面貌" << endl;
        cout << "请选择: ";
        cin >> choice;
        cin.ignore();
        cout << "请输入筛选值: ";
        getline(cin, key);

        bool found = false;
        Student* current = head;
        while (current != nullptr) {
            bool match = false;
            switch (choice) {
            case 1: match = (current->college == key); break;
            case 2: match = (current->major == key); break;
            case 3: match = (current->className == key); break;
            case 4: match = (current->gender == key); break;
            case 5: match = (current->politics == key); break;
            default: cout << "无效选择！" << endl; return;
            }
            if (match) {
                displayStudent(current);
                found = true;
            }
            current = current->next;
        }
        if (!found) cout << "未找到符合条件的学生！" << endl;
    }

    // 运行系统
    void run() {
        int choice;
        do {
            menu();
            cout << "请输入您的选择 (0-7): ";
            cin >> choice;
            cin.ignore();
            switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: deleteStudent(); break;
            case 5: modifyStudent(); break;
            case 6: sortStudents(); break;
            case 7: filterStudents(); break;
            case 0: cout << "系统退出！" << endl; break;
            default: cout << "无效选择！" << endl;
            }
        } while (choice != 0);
    }
};

// 主函数
int main() {
    StudentManager manager;
    manager.run();
    return 0;
}